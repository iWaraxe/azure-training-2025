# First demo. 

1. Open azure portal and walk student throught subscription, tenant configuration.
2. Create resource group manually. Show how azure displays an information about resource (settings, info, other blades, etc.. )
3. Create service principal manually, explain that this is etrypoint for the automation. Assigne contributor permissions with RBAC on subscription level.
4. Create resource group with terraform. Talk about terraform briefly:
    - Terraform plan, apply, output details, provider, resource, local variable, state file
> terraform init
> terraform apply
5. Explain how to find the terraform code and use terraform web site. 