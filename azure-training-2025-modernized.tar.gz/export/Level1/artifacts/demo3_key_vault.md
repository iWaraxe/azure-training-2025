1. Run shell, cd demo2_storage and deploy code with terraform:
> terraform workspace new ops
> terraform init -var-file ..\variables\ops.tfvars
> terraform apply -var-file ..\variables\ops.tfvars
2. Explain:
- for_each
- explain resource configuration
- explain random_password function and show were to find another functions
3. Open azure portal and walk student throught UI resource configuration. 

