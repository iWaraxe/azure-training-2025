1. Run shell, cd demo4_vm and deploy code with terraform:
> terraform workspace new ops
> terraform init -var-file ..\variables\ops.tfvars
> terraform apply -var-file ..\variables\ops.tfvars
2. Explain:
- how we put password for vm 
- how we install jenkins on vm
- the deployment output for jenkins installation
3. Open azure portal and walk student throught UI resource configuration. 

