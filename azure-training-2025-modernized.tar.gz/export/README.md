# Azure Training Course 2025
